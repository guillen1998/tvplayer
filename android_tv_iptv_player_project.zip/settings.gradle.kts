rootProject.name = "TVPlayer"
include(":app")
